# Motor mount STEP review package

Start with `00_COMPLETE_MOTOR_MOUNT.step`: the current fuse-service motor station in its assembled positions, including the wall dock, adapter, case, spool, encoder, homing mechanism and electronics references.

This package covers ONE MOTOR MOUNT, not the suspended claw.

- 01_PRINTED_PARTS: all21 individual printable station components, including revised cover, carrier and fuse support.
- 02_PURCHASED_PART_ENVELOPES: nominal purchased-component references and explicit space reservations. These are simplified envelopes, not supplier production models. The spool is the printable `winch_spool_v2.step`, not a second purchased reference.
- 03_BENCH_FIXTURES: two optional test/fit pieces, not installed in the complete assembly.
- 04_FASTENER_ENVELOPES: locally modeled fasteners; this is not a guaranteed complete assembly fastener BOM.

All dimensions are millimeters. Individual STEP parts retain assembly coordinates: +Y is up along the wall, +Z points away from the wall, and the motor/spool shaft is along X. Preserve these coordinates when reconstructing the assembly. STL print orientations from the earlier print kit differ from these STEP coordinates.

STEP transfers geometry and available assembly hierarchy; it does not supply native SolidWorks features, functional mates, an engineering drawing or a solved motion model. Review imported organization and assign native mates as needed. Source geometry is CadQuery.

Suggested inspection order: dock/adapter capture and lock; spool/shaft and encoder alignment; cable path through guide and collar; switch travel; cover clearance; board retention; fuse support removal and wire access.

Current scope is UNPOWERED FIT PROTOTYPE. Cable bend suitability, actual purchased dimensions, complete downstream harness, retention, temperature and lifting capacity remain unverified. Wire sweeps are provisional clearance envelopes. The complete STEP includes space reservations that can be hidden for visual inspection. No cable operating pose or continuous swept motion is implied.

Read the included independent review for service details. Both fuse leads must be disconnected/released and displaced before support screw access; remove support and holder together, then unthread the lower lead off-case.
